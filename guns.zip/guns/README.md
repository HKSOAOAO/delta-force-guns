# guns

A Pen created on CodePen.

Original URL: [https://codepen.io/HKSOAOAO/pen/gbpvqjL](https://codepen.io/HKSOAOAO/pen/gbpvqjL).

